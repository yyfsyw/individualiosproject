//
//  ViewController.swift
//  Yy5mcNotifier
//
//  Created by YUNFEI YANG on 1/30/17.
//  Copyright © 2017 YUNFEI YANG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var message: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func notify(_ sender: Any) {
        message.text="You have been notified!"
        
    }

    @IBAction func clear(_ sender: Any) {
        message.text=""
        
    }
}

