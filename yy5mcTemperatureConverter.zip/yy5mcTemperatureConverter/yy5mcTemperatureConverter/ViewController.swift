//
//  ViewController.swift
//  yy5mcTemperatureConverter
//
//  Created by YUNFEI YANG on 2/6/17.
//  Copyright © 2017 YUNFEI YANG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var input: UITextField!

    @IBOutlet weak var output: UILabel!
    @IBAction func Convert(_ sender: Any) {
        let s=(`input`.text)! as NSString
        //
        var i=s.doubleValue
        i=i-32
        i=i/1.8
        output.text=String(format: "%.2f", i)
        //"\(doubleVal)"
        //String(format: "%.2f", doubleVal)
    }//end func Convert
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

